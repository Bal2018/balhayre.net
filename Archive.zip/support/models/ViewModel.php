<?php

/**
 * Created by PhpStorm.
 * User: darylcecile
 * Date: 22/10/2018
 * Time: 15:04
 */
class ViewModel
{
    public $name = "";
    public $data = [];

}