declare let $;

//TODO change this to push info to DB

function submitArticle(){
    RoadsterMate.request({
        url:"/article/upload",
        type :"POST",
        data : {
            "article":{
                title : '',
                contents :'',
                image :'',
                categories : '',
                isuseful: ''
            }
        },
        onSuccess:(resp => {
            console.log(resp)

        })
    })


}

// Initialize the editor.
$('.editor-content').froalaEditor();